//Seyed Tavafi
//CS3560
//Programming Assignment 1 - iVote Simulator
//Dr.Sun

package com.company;

import student.*;
import question.*;

import java.util.Arrays;

import voting.VotingSystem;

public class SimulationDriver {
    public static void main(String[] args) {

        int minStudent = 10;
        int maxStudent = 100;
        int minQuestion = 10;
        int maxQuestion = 20;

        System.out.println();

        Student[] students = generateStudent(minStudent, maxStudent);
        System.out.println("*STUDENTS ARE : ");
        System.out.println(Arrays.toString(students));

        System.out.println();
        System.out.println("-------------------------------");
        System.out.println();

        Question[] questions = generateQuestion(minQuestion, maxQuestion);
        System.out.println("*QUESTIONS ARE : ");
        System.out.println(Arrays.toString(questions));

        System.out.println();
        System.out.println("-------------------------------");
        System.out.println();

        System.out.println("*START SIMULATION ...");

        VotingSystem Voting = new VotingSystem(students, questions);

        Voting.voting();

        System.out.println();
        System.out.println("-------------------------------");
        System.out.println();

        System.out.println("*RESULTS ...");

        Voting.result();
    }


    /**
     * Build the student to the given number.
     *
     * @param minStudent ,maxStudent
     * @return Student[]
     */
    private static Student[] generateStudent(int minStudent, int maxStudent) {
        int randomStudent = (int) (Math.random() * (maxStudent - minStudent + 1) + minStudent);

        Student[] students = new Student[randomStudent];

        for (int i = 0; i < randomStudent; i++) {
            int c = i + 1;
            Student stu = new Student(c, "fName" + c, "lName" + c, "field" + c);
            students[i] = stu;
        }
        return students;
    }

    /**
     * Build the question to the given number.
     *
     * @param minQuestion ,maxQuestion
     * @return Question[]
     */
    private static Question[] generateQuestion(int minQuestion, int maxQuestion) {
        int randomQuestion = (int) (Math.random() * (maxQuestion - minQuestion + 1) + minQuestion);

        Question[] questions = new Question[randomQuestion];

        for (int i = 0; i < randomQuestion; i++) {
            Question question;
            if (Math.random() < 0.5) {
                question = new BothQuestion("BothQuestion" + i + " ?");
            } else {
                question = new MultiQuestion("MultiQuestion" + i + " ?");
            }
            questions[i] = question;
        }
        return questions;
    }
}