package student;

public class Student implements StudentInterface{

    private int id;
    private String firstName;
    private String lastName;
    private String field;

    public Student(int id, String firstName, String lastName, String field) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.field = field;
    }

    /**
     * get id.
     *
     * @return id
     */
    public int getId() {
        return this.id;
    }

    /**
     * set id.
     *
     * @param id int
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * get firstName.
     *
     * @return firstName
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * set firstName.
     *
     * @param firstName String
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * get lastName.
     *
     * @return lastName
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * set lastName.
     *
     * @param lastName String
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * get field.
     *
     * @return field
     */
    public String getField() {
        return this.field;
    }

    /**
     * set field.
     *
     * @param field String
     */
    public void setField(String field) {
        this.field = field;
    }

    /**
     * get fullName.
     *
     * @return fullName of student
     */
    public String getFullName() {
        return this.firstName + ' ' + this.lastName;
    }

    /**
     * Description after making the object.
     *
     * @return Description of the student
     */
    public String toString() {
        return "Student => " + "id : " + id + ", name : " + getFullName() + ", field : " + field + "\n";
    }

}
