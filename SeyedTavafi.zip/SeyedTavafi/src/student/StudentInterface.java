package student;

public interface StudentInterface {
    /**
     * get id.
     *
     * @return id
     */
    int getId();

    /**
     * set id.
     *
     * @param id int
     */
    void setId(int id);

    /**
     * get firstName.
     *
     * @return firstName
     */
    String getFirstName();

    /**
     * set firstName.
     *
     * @param firstName String
     */
    void setFirstName(String firstName);

    /**
     * get lastName.
     *
     * @return lastName
     */
    String getLastName();

    /**
     * set lastName.
     *
     * @param lastName String
     */
    void setLastName(String lastName);

    /**
     * get field.
     *
     * @return field
     */
    String getField();

    /**
     * set field.
     *
     * @param field String
     */
    void setField(String field);

    /**
     * get fullName.
     *
     * @return fullName of student
     */
    String getFullName();

    /**
     * Description after making the object.
     *
     * @return Description of the student
     */
    String toString();
}
