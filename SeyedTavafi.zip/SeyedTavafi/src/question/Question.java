package question;

public class Question implements Answer ,QuestionInterface{

    private Object question;
    private Object answer = "no answer";
    private String type;

    public Question() {

    }

    public Question(String question, String type) {
        this.setQuestion(question);
        this.setType(type);
    }

    public Question(String question, Object answer, String type) {
        this.setQuestion(question);
        this.setAnswer(answer);
        this.setType(type);
    }

    /**
     * get question.
     *
     * @return question
     */
    public Object getQuestion() {
        return this.question;
    }

    /**
     * set question.
     *
     * @param question String
     */
    public void setQuestion(String question) {
        this.question = question;
    }

    /**
     * get answer.
     *
     * @return answer
     */
    public Object getAnswer() {
        return this.answer;
    }

    /**
     * set answer.
     *
     * @param answer Object
     */
    public void setAnswer(Object answer) {
        this.answer = answer;
    }

    /**
     * get type.
     *
     * @return type
     */
    public String getType() {
        return this.type;
    }

    /**
     * set type.
     *
     * @param type String
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Description after making the object.
     *
     * @return Description of the question
     */
    public String toString() {
        return "Question => " + "question : " + question + " , type : " + type + "\n" + "   answer : " + answer + "\n";
    }

    /**
     * clone the question.
     *
     * @param question String
     * @return new Question()
     */
    public Question clone(String question) {
        return new Question();
    }

}
