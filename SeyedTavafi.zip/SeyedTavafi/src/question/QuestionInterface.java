package question;

public interface QuestionInterface {
    /**
     * get question.
     *
     * @return question
     */
    Object getQuestion();

    /**
     * set question.
     *
     * @param question String
     */
    void setQuestion(String question);

    /**
     * get answer.
     *
     * @return answer
     */
    Object getAnswer();

    /**
     * set answer.
     *
     * @param answer Object
     */
    void setAnswer(Object answer);

    /**
     * get type.
     *
     * @return type
     */
    String getType();

    /**
     * set type.
     *
     * @param type String
     */
    void setType(String type);

    /**
     * Description after making the object.
     *
     * @return Description of the question
     */
    String toString();

    /**
     * clone the question.
     *
     * @param question String
     * @return new Question()
     */
    Question clone(String question);
}
