package question;

public interface Answer {
    /**
     * get answer.
     */
    Object getAnswer();

    /**
     * set answer.
     *
     * @param answer Object
     */
    void setAnswer(Object answer);
}
