package question;

public enum BothAnswerType {
    Right, Wrong
}
