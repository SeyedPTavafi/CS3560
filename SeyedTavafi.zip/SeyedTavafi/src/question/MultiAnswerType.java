package question;

public enum MultiAnswerType {
    A, B, C, D
}