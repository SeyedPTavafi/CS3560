package question;

public class MultiQuestion extends Question {

    private int a;
    private int b;
    private int c;
    private int d;

    public MultiQuestion(String question) {
        super(question, "multi");
    }

    /**
     * add a option to this question.
     */
    public void add_A() {
        this.a = this.a + 1;
    }

    /**
     * get a option.
     *
     * @return a
     */
    public int get_A() {
        return this.a;
    }

    /**
     * add b option to this question.
     */
    public void add_B() {
        this.b = this.b + 1;
    }

    /**
     * get b option.
     *
     * @return b
     */
    public int get_B() {
        return this.b;
    }

    /**
     * add c option to this question.
     */
    public void add_C() {
        this.c = this.c + 1;
    }

    /**
     * get c option.
     *
     * @return c
     */
    public int get_C() {
        return this.c;
    }

    /**
     * add d option to this question.
     */
    public void add_D() {
        this.d = this.d + 1;
    }

    /**
     * get d option.
     *
     * @return d
     */
    public int get_D() {
        return this.d;
    }

    /**
     * clone the multi question.
     *
     * @param question String
     * @return new MultiQuestion
     */
    public MultiQuestion clone(String question) {
        return new MultiQuestion(question);
    }

}