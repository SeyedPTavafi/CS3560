package question;

public class BothQuestion extends Question {

    private int rightOption;
    private int wrongOption;

    public BothQuestion(String question) {
        super(question, "both");
    }

    /**
     * add right option to this question.
     */
    public void addRightOption() {
        this.rightOption = this.rightOption + 1;
    }

    /**
     * get right option.
     *
     * @return rightOption
     */
    public int getRightOption() {
        return this.rightOption;
    }
    /**
     * add wrong option to this question.
     */
    public void addWrongOption() {
        this.wrongOption = this.wrongOption + 1;
    }

    /**
     * get wrong option.
     *
     * @return wrongOption
     */
    public int getWrongOption() {
        return this.wrongOption;
    }

    /**
     * clone the both question.
     *
     * @param question String
     * @return new BothQuestion
     */
    public BothQuestion clone(String question) {
        return new BothQuestion(question);
    }

}